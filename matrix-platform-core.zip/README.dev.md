Run client + server with: npm run dev
