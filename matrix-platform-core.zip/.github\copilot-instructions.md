Matrix Platform Copilot Instructions
