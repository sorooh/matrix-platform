module.exports = {run:(r,res)=>res.json({success:true})};
