Governance rules for Matrix Platform
